﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DSAProject
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void iconButton1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void iconButton1_Click_1(object sender, EventArgs e)
        {
            insert s = new insert();
            this.Hide();
            s.Show();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            Delete d = new Delete();
            this.Hide();
            d.Show();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            Search s = new Search();
            this.Hide();
            s.Show();
        }

        private void home_Load(object sender, EventArgs e)
        {
            string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";
            List<string[]> data = ReadDataFromFile(filePath);
            DisplayDataInGrid(data);
        }
        private void DisplayDataInGrid(List<string[]> data)
        {
            grid.Rows.Clear();

            foreach (string[] row in data)
            {
                grid.Rows.Add(row);
            }
        }
        private List<string[]> ReadDataFromFile(string filePath)
        {
            List<string[]> data = new List<string[]>();

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] values = line.Split(' ');
                    data.Add(values);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return data;
        }

        private void guna2GradientCircleButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
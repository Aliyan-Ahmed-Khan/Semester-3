﻿namespace DSAProject
{
    partial class Delete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            grid2 = new Guna.UI2.WinForms.Guna2DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            textBox2 = new TextBox();
            label1 = new Label();
            guna2GradientCircleButton2 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            textBox1 = new TextBox();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grid2).BeginInit();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.BackColor = Color.White;
            guna2Panel1.Controls.Add(grid2);
            guna2Panel1.Controls.Add(guna2GradientButton1);
            guna2Panel1.Controls.Add(textBox2);
            guna2Panel1.Controls.Add(label1);
            guna2Panel1.Controls.Add(guna2GradientCircleButton2);
            guna2Panel1.Controls.Add(guna2Panel2);
            guna2Panel1.Controls.Add(textBox1);
            guna2Panel1.CustomizableEdges = customizableEdges6;
            guna2Panel1.Location = new Point(-1, -1);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges7;
            guna2Panel1.Size = new Size(919, 572);
            guna2Panel1.TabIndex = 1;
            // 
            // grid2
            // 
            dataGridViewCellStyle1.BackColor = Color.FromArgb(247, 201, 197);
            grid2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(231, 76, 60);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 8.765218F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            grid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            grid2.ColumnHeadersHeight = 22;
            grid2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            grid2.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3 });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(249, 219, 216);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 8.765218F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(239, 135, 125);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            grid2.DefaultCellStyle = dataGridViewCellStyle3;
            grid2.GridColor = Color.FromArgb(245, 192, 188);
            grid2.Location = new Point(160, 234);
            grid2.Name = "grid2";
            grid2.RowHeadersVisible = false;
            grid2.RowHeadersWidth = 49;
            grid2.RowTemplate.Height = 28;
            grid2.Size = new Size(588, 180);
            grid2.TabIndex = 28;
            grid2.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Alizarin;
            grid2.ThemeStyle.AlternatingRowsStyle.BackColor = Color.FromArgb(247, 201, 197);
            grid2.ThemeStyle.AlternatingRowsStyle.Font = null;
            grid2.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            grid2.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            grid2.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            grid2.ThemeStyle.BackColor = Color.White;
            grid2.ThemeStyle.GridColor = Color.FromArgb(245, 192, 188);
            grid2.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(231, 76, 60);
            grid2.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            grid2.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 8.765218F, FontStyle.Regular, GraphicsUnit.Point);
            grid2.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            grid2.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            grid2.ThemeStyle.HeaderStyle.Height = 22;
            grid2.ThemeStyle.ReadOnly = false;
            grid2.ThemeStyle.RowsStyle.BackColor = Color.FromArgb(249, 219, 216);
            grid2.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            grid2.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 8.765218F, FontStyle.Regular, GraphicsUnit.Point);
            grid2.ThemeStyle.RowsStyle.ForeColor = Color.Black;
            grid2.ThemeStyle.RowsStyle.Height = 28;
            grid2.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(239, 135, 125);
            grid2.ThemeStyle.RowsStyle.SelectionForeColor = Color.Black;
            // 
            // Column1
            // 
            Column1.HeaderText = "SKU";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "NAME";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "PRICE";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            // 
            // guna2GradientButton1
            // 
            guna2GradientButton1.CustomizableEdges = customizableEdges1;
            guna2GradientButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton1.FillColor = Color.FromArgb(248, 131, 121);
            guna2GradientButton1.FillColor2 = Color.FromArgb(248, 131, 121);
            guna2GradientButton1.FocusedColor = Color.FromArgb(248, 131, 121);
            guna2GradientButton1.Font = new Font("Segoe UI", 8.765218F, FontStyle.Bold, GraphicsUnit.Point);
            guna2GradientButton1.ForeColor = Color.White;
            guna2GradientButton1.Location = new Point(537, 155);
            guna2GradientButton1.Name = "guna2GradientButton1";
            guna2GradientButton1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2GradientButton1.Size = new Size(87, 33);
            guna2GradientButton1.TabIndex = 27;
            guna2GradientButton1.Text = "Delete";
            guna2GradientButton1.Click += guna2GradientButton1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(371, 158);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(137, 26);
            textBox2.TabIndex = 26;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.0173912F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(248, 131, 121);
            label1.Location = new Point(304, 161);
            label1.Name = "label1";
            label1.Size = new Size(41, 21);
            label1.TabIndex = 21;
            label1.Text = "SKU";
            // 
            // guna2GradientCircleButton2
            // 
            guna2GradientCircleButton2.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientCircleButton2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientCircleButton2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientCircleButton2.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientCircleButton2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientCircleButton2.FillColor = Color.FromArgb(248, 131, 121);
            guna2GradientCircleButton2.FillColor2 = Color.FromArgb(248, 131, 121);
            guna2GradientCircleButton2.Font = new Font("Segoe UI", 8.765218F, FontStyle.Bold, GraphicsUnit.Point);
            guna2GradientCircleButton2.ForeColor = Color.White;
            guna2GradientCircleButton2.Location = new Point(845, 24);
            guna2GradientCircleButton2.Name = "guna2GradientCircleButton2";
            guna2GradientCircleButton2.ShadowDecoration.CustomizableEdges = customizableEdges3;
            guna2GradientCircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2GradientCircleButton2.Size = new Size(47, 42);
            guna2GradientCircleButton2.TabIndex = 20;
            guna2GradientCircleButton2.Text = "X";
            guna2GradientCircleButton2.Click += guna2GradientCircleButton2_Click;
            // 
            // guna2Panel2
            // 
            guna2Panel2.BackColor = Color.FromArgb(248, 131, 121);
            guna2Panel2.CustomizableEdges = customizableEdges4;
            guna2Panel2.Location = new Point(-1, 83);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2Panel2.Size = new Size(923, 10);
            guna2Panel2.TabIndex = 19;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.White;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.ForeColor = Color.FromArgb(248, 131, 121);
            textBox1.Location = new Point(283, 33);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(341, 31);
            textBox1.TabIndex = 18;
            textBox1.Text = "Product Inventory Management";
            // 
            // Delete
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 570);
            Controls.Add(guna2Panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Delete";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form2";
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grid2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2DataGridView grid2;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private TextBox textBox2;
        private Label label1;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton2;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private TextBox textBox1;
    }
}
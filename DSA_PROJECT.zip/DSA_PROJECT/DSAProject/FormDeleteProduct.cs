﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DSAProject
{
    public partial class FormDeleteProduct : Form
    {
        public string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";

        public FormDeleteProduct()
        {
            InitializeComponent();
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            FormAddProduct addbutton = new FormAddProduct();
            addbutton.Show();
            this.Hide();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            FormSearchProduct searchbutton = new FormSearchProduct();
            searchbutton.Show();
            this.Hide();
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            //FormaddedProductHistory historybutton = new FormaddedProductHistory();
            //historybutton.Show();
            //this.Hide();
        }

        private void DisplayDataInGrid(List<string[]> data)
        {
            dataGridView1.Rows.Clear();

            foreach (string[] row in data)
            {
                dataGridView1.Rows.Add(row);
            }
        }

        private void FormDeleteProduct_Load(object sender, EventArgs e)
        {
            string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";
            List<string[]> data = ReadDataFromFile(filePath);
            DisplayDataInGrid(data);
        }
        private List<string[]> ReadDataFromFile(string filePath)
        {
            List<string[]> data = new List<string[]>();

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] values = line.Split(' ');
                    data.Add(values);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return data;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string sku = textBox2.Text;

            if (!string.IsNullOrEmpty(sku))
            {
                string[] lines = File.ReadAllLines(filePath);

                int lineIndex = -1;
                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].StartsWith(sku))
                    {
                        lineIndex = i;
                        break;
                    }
                }

                if (lineIndex != -1)
                {
                    // Remove the line with the given ID
                    var updatedLines = new List<string>(lines);
                    updatedLines.RemoveAt(lineIndex);

                    // Write the updated content back to the file
                    File.WriteAllLines(filePath, updatedLines);

                    MessageBox.Show($"Record with ID {sku} deleted successfully.");

                    Form1 deleted = new Form1();
                    deleted.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show($"Record with ID {sku} not found.");
                }
            }
            else
            {
                MessageBox.Show("Please enter an ID.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "FormDeleteProduct")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

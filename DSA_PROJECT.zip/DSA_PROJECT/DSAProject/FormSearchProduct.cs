﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DSAProject
{
    public partial class FormSearchProduct : Form
    {

        public FormSearchProduct()
        {
            InitializeComponent();
            string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";
            List<string[]> data = ReadDataFromFile(filePath);
            DisplayDataInGrid(data);

        }
        private List<string[]> ReadDataFromFile(string filePath)
        {
            List<string[]> data = new List<string[]>();

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] values = line.Split(' ');
                    data.Add(values);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return data;
        }
        private void FormSearchProduct_Load(object sender, EventArgs e)
        {
            
        }
        private void DisplayDataInGrid(List<string[]> data)
        {
            dataGridView1.Rows.Clear();

            foreach (string[] row in data)
            {
                dataGridView1.Rows.Add(row);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string target = textBox2.Text;
                string[] id = new string[dataGridView1.Rows.Count];

                for (int i = 0; i <id.Length; i++)
                {
                    // Check for null values before calling ToString()
                    id[i] = dataGridView1.Rows[i].Cells[0].Value?.ToString() ?? string.Empty;
                }
                InsertionSort(id);
                int result=InterpolationSearch(id, target);

                if (result != -1)
                {
                    MessageBox.Show($"Element '{target}' found at index {result}");
                }
                else
                {
                    MessageBox.Show($"Element '{target}' not found");
                }
            }
            catch(Exception){ MessageBox.Show("ERROR");}
        }

        static void InsertionSort(string[] arr)
        {
            for (int i = 1; i < arr.Length; i++)
            {
                string key = arr[i];
                int j = i - 1;

                while (j >= 0 && String.Compare(arr[j], key) > 0)
                {
                    arr[j + 1] = arr[j];
                    j--;
                }

                arr[j + 1] = key;
            }
        }

        static int InterpolationSearch(string[] id, string target)
        {
            int low = 0;
            int high = id.Length - 1;

            while (low <= high && String.Compare(target, id[low]) >= 0 && String.Compare(target, id[high]) <= 0)
            {
                int pos = low + ((String.Compare(target, id[low]) * (high - low)) / (String.Compare(id[high], id[low]) == 0 ? 1 : String.Compare(id[high], id[low])));

                if (String.Equals(id[pos], target))
                    return pos;

                if (String.Compare(id[pos], target) < 0)
                    low = pos + 1;
                else
                    high = pos - 1;
            }
            return -1;  
        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            FormAddProduct addbutton = new FormAddProduct();
            addbutton.Show();
            this.Hide();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            FormDeleteProduct deletebutton = new FormDeleteProduct();
            deletebutton.Show();
            this.Hide();
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            //FormaddedProductHistory historybutton = new FormaddedProductHistory();
            //historybutton.Show();
            //this.Hide();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "FormSearchProduct")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void LoadDataFromFile()
        {
            // Specify the path to your data file
            string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";

            // Check if the file exists
            if (File.Exists(filePath))
            {
                // Read all lines from the file and add them to the ListBox
                string[] lines = File.ReadAllLines(filePath);

            }
            else
            {
                MessageBox.Show("Data file not found.");
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FormSearchProduct_Load_1(object sender, EventArgs e)
        {
            LoadDataFromFile();
        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
﻿namespace DSAProject
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            grid3 = new Guna.UI2.WinForms.Guna2DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            textBox4 = new TextBox();
            label1 = new Label();
            guna2GradientCircleButton1 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            textBox1 = new TextBox();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)grid3).BeginInit();
            SuspendLayout();
            // 
            // guna2Panel1
            // 
            guna2Panel1.BackColor = Color.White;
            guna2Panel1.Controls.Add(grid3);
            guna2Panel1.Controls.Add(guna2GradientButton1);
            guna2Panel1.Controls.Add(textBox4);
            guna2Panel1.Controls.Add(label1);
            guna2Panel1.Controls.Add(guna2GradientCircleButton1);
            guna2Panel1.Controls.Add(guna2Panel2);
            guna2Panel1.Controls.Add(textBox1);
            guna2Panel1.CustomizableEdges = customizableEdges6;
            guna2Panel1.Location = new Point(0, -2);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges7;
            guna2Panel1.Size = new Size(919, 572);
            guna2Panel1.TabIndex = 2;
            guna2Panel1.Paint += guna2Panel1_Paint;
            // 
            // grid3
            // 
            dataGridViewCellStyle1.BackColor = Color.FromArgb(247, 201, 197);
            grid3.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(231, 76, 60);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 8.765218F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            grid3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            grid3.ColumnHeadersHeight = 22;
            grid3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            grid3.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3 });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(249, 219, 216);
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 8.765218F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(239, 135, 125);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            grid3.DefaultCellStyle = dataGridViewCellStyle3;
            grid3.GridColor = Color.FromArgb(245, 192, 188);
            grid3.Location = new Point(182, 235);
            grid3.Name = "grid3";
            grid3.RowHeadersVisible = false;
            grid3.RowHeadersWidth = 49;
            grid3.RowTemplate.Height = 28;
            grid3.Size = new Size(588, 180);
            grid3.TabIndex = 28;
            grid3.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.Alizarin;
            grid3.ThemeStyle.AlternatingRowsStyle.BackColor = Color.FromArgb(247, 201, 197);
            grid3.ThemeStyle.AlternatingRowsStyle.Font = null;
            grid3.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            grid3.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            grid3.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            grid3.ThemeStyle.BackColor = Color.White;
            grid3.ThemeStyle.GridColor = Color.FromArgb(245, 192, 188);
            grid3.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(231, 76, 60);
            grid3.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            grid3.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 8.765218F, FontStyle.Regular, GraphicsUnit.Point);
            grid3.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            grid3.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            grid3.ThemeStyle.HeaderStyle.Height = 22;
            grid3.ThemeStyle.ReadOnly = false;
            grid3.ThemeStyle.RowsStyle.BackColor = Color.FromArgb(249, 219, 216);
            grid3.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            grid3.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 8.765218F, FontStyle.Regular, GraphicsUnit.Point);
            grid3.ThemeStyle.RowsStyle.ForeColor = Color.Black;
            grid3.ThemeStyle.RowsStyle.Height = 28;
            grid3.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(239, 135, 125);
            grid3.ThemeStyle.RowsStyle.SelectionForeColor = Color.Black;
            // 
            // Column1
            // 
            Column1.HeaderText = "SKU";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "NAME";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            // 
            // Column3
            // 
            Column3.HeaderText = "PRICE";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            // 
            // guna2GradientButton1
            // 
            guna2GradientButton1.CustomizableEdges = customizableEdges1;
            guna2GradientButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton1.FillColor = Color.FromArgb(248, 131, 121);
            guna2GradientButton1.FillColor2 = Color.FromArgb(248, 131, 121);
            guna2GradientButton1.FocusedColor = Color.FromArgb(248, 131, 121);
            guna2GradientButton1.Font = new Font("Segoe UI", 8.765218F, FontStyle.Bold, GraphicsUnit.Point);
            guna2GradientButton1.ForeColor = Color.White;
            guna2GradientButton1.Location = new Point(542, 155);
            guna2GradientButton1.Name = "guna2GradientButton1";
            guna2GradientButton1.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2GradientButton1.Size = new Size(87, 33);
            guna2GradientButton1.TabIndex = 27;
            guna2GradientButton1.Text = "Search";
            guna2GradientButton1.Click += guna2GradientButton1_Click;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(376, 158);
            textBox4.Margin = new Padding(3, 4, 3, 4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(137, 26);
            textBox4.TabIndex = 26;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.0173912F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(248, 131, 121);
            label1.Location = new Point(309, 161);
            label1.Name = "label1";
            label1.Size = new Size(41, 21);
            label1.TabIndex = 21;
            label1.Text = "SKU";
            // 
            // guna2GradientCircleButton1
            // 
            guna2GradientCircleButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientCircleButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientCircleButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientCircleButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientCircleButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientCircleButton1.FillColor = Color.FromArgb(248, 131, 121);
            guna2GradientCircleButton1.FillColor2 = Color.FromArgb(248, 131, 121);
            guna2GradientCircleButton1.Font = new Font("Segoe UI", 8.765218F, FontStyle.Bold, GraphicsUnit.Point);
            guna2GradientCircleButton1.ForeColor = Color.White;
            guna2GradientCircleButton1.Location = new Point(845, 24);
            guna2GradientCircleButton1.Name = "guna2GradientCircleButton1";
            guna2GradientCircleButton1.ShadowDecoration.CustomizableEdges = customizableEdges3;
            guna2GradientCircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2GradientCircleButton1.Size = new Size(47, 42);
            guna2GradientCircleButton1.TabIndex = 20;
            guna2GradientCircleButton1.Text = "X";
            guna2GradientCircleButton1.Click += guna2GradientCircleButton1_Click;
            // 
            // guna2Panel2
            // 
            guna2Panel2.BackColor = Color.FromArgb(248, 131, 121);
            guna2Panel2.CustomizableEdges = customizableEdges4;
            guna2Panel2.Location = new Point(-1, 83);
            guna2Panel2.Name = "guna2Panel2";
            guna2Panel2.ShadowDecoration.CustomizableEdges = customizableEdges5;
            guna2Panel2.Size = new Size(923, 10);
            guna2Panel2.TabIndex = 19;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.White;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Segoe UI Semibold", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.ForeColor = Color.FromArgb(248, 131, 121);
            textBox1.Location = new Point(283, 33);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(620, 31);
            textBox1.TabIndex = 18;
            textBox1.Text = "Product Inventory Management";
            // 
            // Search
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(919, 572);
            Controls.Add(guna2Panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Search";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Search";
            guna2Panel1.ResumeLayout(false);
            guna2Panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)grid3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2DataGridView grid3;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private TextBox textBox4;
        private Label label1;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private TextBox textBox1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace DSAProject
{
    public partial class FormAddProduct : Form
    {
        string a, b, c;
         
        public FormAddProduct()
        {
            InitializeComponent();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            FormDeleteProduct deletebutton = new FormDeleteProduct();
            deletebutton.Show();
            this.Hide();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {   
            FormSearchProduct searchbutton = new FormSearchProduct();
            searchbutton.Show();
            this.Hide();
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
      
            FormaddedProductHistory historybutton = new FormaddedProductHistory();
            historybutton.display();
            historybutton.Show();
            this.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void DisplayDataInGrid(List<string[]> data)
        {
            dataGridView1.Rows.Clear();

            foreach (string[] row in data)
            {
                dataGridView1.Rows.Add(row);
            }
        }

        private List<string[]> ReadDataFromFile(string filePath)
        {
            List<string[]> data = new List<string[]>();

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] values = line.Split(' ');
                    data.Add(values);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return data;
        }

        private void panelLogo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FormAddProduct_Load(object sender, EventArgs e)
        {
            string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";
            List<string[]> data = ReadDataFromFile(filePath);
            DisplayDataInGrid(data);
        }
        public string get()
        {
            a = textBox4.Text;
            b = textBox3.Text;
            c = textBox2.Text;
            return a + " " + b + " " + c;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox4.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Please enter valid data in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                string sku = textBox4.Text;
                string[] lines = File.ReadAllLines("C:/Users/PMLS/Documents/ProductsInfo.txt");

                // Check if SKU ID already exists
                foreach (string line in lines)
                {
                    if (line.StartsWith(sku))
                    {
                        MessageBox.Show($"SKU ID {sku} already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }

                List<string> sortedLines = lines.ToList();
                sortedLines.Add(textBox4.Text + " " + textBox3.Text + " " + textBox2.Text);
                InsertionSort(sortedLines);

                // Write the sorted data back to the file
                File.WriteAllLines("C:/Users/PMLS/Documents/ProductsInfo.txt", sortedLines);

                var path = "C:/Users/PMLS/Documents/ProductsInfo.txt";
                using (FileStream file = new FileStream(path, FileMode.Append, FileAccess.Write))
                {
                    using (StreamWriter write = new StreamWriter(file))
                    {
                        write.WriteLine(textBox4.Text + " " + textBox3.Text + " " + textBox2.Text);
                    }
                }
                 

                





                // Open FormAddedProductHistory and pass the history data

                textBox4.Clear();
                textBox3.Clear();
                textBox2.Clear();
                if (MessageBox.Show("Another product has been added!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
                {
                    Form1 added = new Form1();
                    added.Show();
                    this.Hide();
                }
            }
        }

        private void InsertionSort(List<string> list)
        {
            for (int i = 1; i < list.Count; i++)
            {
                string current = list[i];
                int j = i - 1;

                // Move elements of list[0..i-1] that are greater than current
                // to one position ahead of their current position
                while (j >= 0 && string.Compare(list[j], current) > 0)
                {
                    list[j + 1] = list[j];
                    j--;
                }

                list[j + 1] = current;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "FormAddProduct")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
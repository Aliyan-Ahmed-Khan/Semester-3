﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;

namespace DSAProject
{
    public partial class FormaddedProductHistory : Form
    {

        string[] l;
        string s;
        public FormaddedProductHistory()
        {
            FormAddProduct a = new FormAddProduct();
            InitializeComponent();
            l = new string[3];
            s = a.get();

        }

        public void display()
        {
            l = s.Split(" ");
            dataGridView1.Rows[0].Cells[0].Value = l[0];
            dataGridView1.Rows[0].Cells[1].Value = l[1];
            dataGridView1.Rows[0].Cells[2].Value = l[2];

        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            FormAddProduct addbutton = new FormAddProduct();
            addbutton.Show();
            this.Hide();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            FormDeleteProduct deletebutton = new FormDeleteProduct();
            deletebutton.Show();
            this.Hide();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            FormSearchProduct searchbutton = new FormSearchProduct();
            searchbutton.Show();
            this.Hide();
        }

        //private void DisplayDataInGrid(List<string[]> data)
        //{
        //    dataGridView1.Rows.Clear();

        //    foreach (string[] row in data)
        //    {
        //        dataGridView1.Rows.Add(row);
        //    }
        //}

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "FormdddedProductHistory")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void panelDesktop_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            
        }
    }
}
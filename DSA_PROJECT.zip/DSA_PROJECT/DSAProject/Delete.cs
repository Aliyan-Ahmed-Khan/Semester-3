﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DSAProject
{
    public partial class Delete : Form
    {
        public string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";
        public Delete()
        {
            InitializeComponent();
            string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";
            List<string[]> data = ReadDataFromFile(filePath);
            DisplayDataInGrid(data);
        }
        private void DisplayDataInGrid(List<string[]> data)
        {
            grid2.Rows.Clear();

            foreach (string[] row in data)
            {
                grid2.Rows.Add(row);
            }
        }
        private void guna2GradientCircleButton2_Click(object sender, EventArgs e)
        {
            home m = new home();
            this.Hide();
            m.Show();
        }
        private List<string[]> ReadDataFromFile(string filePath)
        {
            List<string[]> data = new List<string[]>();

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] values = line.Split(' ');
                    data.Add(values);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return data;
        }
        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            string sku = textBox2.Text;

            if (!string.IsNullOrEmpty(sku))
            {
                string[] lines = File.ReadAllLines(filePath);

                int lineIndex = -1;
                for (int i = 0; i < lines.Length; i++)
                {
                    if (lines[i].StartsWith(sku))
                    {
                        lineIndex = i;
                        break;
                    }
                }

                if (lineIndex != -1)
                {
                    // Remove the line with the given ID
                    var updatedLines = new List<string>(lines);
                    updatedLines.RemoveAt(lineIndex);

                    // Write the updated content back to the file
                    File.WriteAllLines(filePath, updatedLines);

                    MessageBox.Show($"Record with ID {sku} deleted successfully.");

                    Delete deleted = new Delete();
                    deleted.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show($"Record with ID {sku} not found.");
                }
            }
            else
            {
                MessageBox.Show("Please enter an ID.");
            }
        }
    }

}
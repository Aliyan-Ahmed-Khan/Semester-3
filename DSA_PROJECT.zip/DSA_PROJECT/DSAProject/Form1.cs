using FontAwesome.Sharp;
namespace DSAProject
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            home cs = new home();
            cs.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";
            List<string[]> data = ReadDataFromFile(filePath);
            DisplayDataInGrid(data);
        }
        private void DisplayDataInGrid(List<string[]> data)
        {
            dataGridView1.Rows.Clear();

            foreach (string[] row in data)
            {
                dataGridView1.Rows.Add(row);
            }
        }
        private List<string[]> ReadDataFromFile(string filePath)
        {
            List<string[]> data = new List<string[]>();

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] values = line.Split(' ');
                    data.Add(values);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return data;
        }
        private void panelMenu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void iconButton1_Click(object sender, EventArgs e)
        {
            FormAddProduct addbutton = new FormAddProduct();
            addbutton.Show();
            this.Hide();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {
            FormDeleteProduct deletebutton = new FormDeleteProduct();
            deletebutton.Show();
            this.Hide();
        }

        private void iconButton3_Click(object sender, EventArgs e)
        {
            FormSearchProduct searchbutton = new FormSearchProduct();
            searchbutton.Show();
            this.Hide();
        }

        private void iconButton4_Click(object sender, EventArgs e)
        {
            //FormaddedProductHistory historybutton = new FormaddedProductHistory(addedhistory);
            //historybutton.Show();
            //this.Hide();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form1")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void panelDesktop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelTitleBar_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
﻿namespace DSAProject
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
            string filePath = "C:/Users/PMLS/Documents/ProductsInfo.txt";
            List<string[]> data = ReadDataFromFile(filePath);
            DisplayDataInGrid(data);
        }
        private List<string[]> ReadDataFromFile(string filePath)
        {
            List<string[]> data = new List<string[]>();

            try
            {
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] values = line.Split(' ');
                    data.Add(values);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading the file: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return data;
        }
        private void DisplayDataInGrid(List<string[]> data)
        {
            grid3.Rows.Clear();

            foreach (string[] row in data)
            {
                grid3.Rows.Add(row);
            }
        }
        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            try
            {
                if (int.TryParse(textBox4.Text, out int target))
                {
                    string[] id = new string[grid3.Rows.Count];

                    for (int i = 0; i < id.Length; i++)
                    {
                        // Check for null values before calling ToString()
                        id[i] = grid3.Rows[i].Cells[0].Value?.ToString() ?? string.Empty;
                    }

                    InsertionSort(id);
                    int result = InterpolationSearch(id, target.ToString());

                    if (result != -1)
                    {
                        MessageBox.Show($"Element '{target}' found at index {result}");
                    }
                    else
                    {
                        MessageBox.Show($"Element '{target}' not found");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid integer in SKU.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("ERROR");
            }
        }
        static void InsertionSort(string[] arr)
        {
            for (int i = 1; i < arr.Length; i++)
            {
                string key = arr[i];
                int j = i - 1;

                while (j >= 0 && String.Compare(arr[j], key) > 0)
                {
                    arr[j + 1] = arr[j];
                    j--;
                }

                arr[j + 1] = key;
            }
        }
        static int InterpolationSearch(string[] id, string target)
        {
            int low = 0;
            int high = id.Length - 1;

            while (low <= high && String.Compare(target, id[low]) >= 0 && String.Compare(target, id[high]) <= 0)
            {
                int pos = low + ((String.Compare(target, id[low]) * (high - low)) / (String.Compare(id[high], id[low]) == 0 ? 1 : String.Compare(id[high], id[low])));

                if (String.Equals(id[pos], target))
                    return pos;

                if (String.Compare(id[pos], target) < 0)
                    low = pos + 1;
                else
                    high = pos - 1;
            }
            return -1;
        }

        private void guna2GradientCircleButton1_Click(object sender, EventArgs e)
        {
            home m = new home();
            this.Hide();
            m.Show();
        }
    }
}